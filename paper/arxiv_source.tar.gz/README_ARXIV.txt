Standard Model Epistemic Graph -- arXiv source
Compile with XeLaTeX (fontspec is used; the fonts are included in fonts/):
    latexmk -xelatex main.tex
Files: main.tex (top level), sec_*.tex, tab_*.tex, numbers.tex, refs_generated.tex (bibliography,
no BibTeX needed), figures/*.png, fonts/*.ttf (subsets of GNU FreeFont and DejaVu Sans Mono;
licences permit redistribution). All tables and numbers are generated from the graph data in the
GitHub repository https://github.com/tahmeedhossain/GEN_HEP.
